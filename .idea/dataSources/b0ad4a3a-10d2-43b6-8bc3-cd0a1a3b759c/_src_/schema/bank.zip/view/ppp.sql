CREATE VIEW ppp AS
  SELECT `p`.`nic` AS `nic`
  FROM `bank`.`person` `p`;
