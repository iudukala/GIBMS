CREATE VIEW lcid_view AS
  (SELECT
     `c`.`customer_id`                                                                                           AS `StateID`,
     `p`.`nic`                                                                                                   AS `NIC`,
     ((((`c`.`earn_career` + `c`.`earn_land`) + `c`.`earn_houses`) + `c`.`earn_business`) +
      `c`.`earn_vehicles`)                                                                                       AS `Total assets`,
     `p`.`full_name`                                                                                             AS `Full name`,
     `c`.`company`                                                                                               AS `Company`
   FROM `bank`.`person` `p`
     JOIN `bank`.`customer_state` `c`
   WHERE (`p`.`nic` = `c`.`nic`));
