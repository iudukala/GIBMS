CREATE VIEW customer_view AS
  (SELECT
     `c`.`customer_id`                                          AS `StateID`,
     `p`.`nic`                                                  AS `NIC`,
     `p`.`full_name`                                            AS `Full name`,
     `p`.`address`                                              AS `Home address`,
     `p`.`phone`                                                AS `Phone no`,
     `c`.`company`                                              AS `Company`,
     `p`.`dob`                                                  AS `Date of birth`,
     if((`p`.`gender` = 'm'), 'Male', 'Female')                 AS `Gender`,
     if((`p`.`marital_status` = 'm'), 'Married', 'Not married') AS `Marital status`,
     `s`.`name`                                                 AS `Spouse name`,
     `s`.`spouse_id`                                            AS `SpouseID`,
     `p`.`email`                                                AS `Email`
   FROM `bank`.`person` `p`
     JOIN (`bank`.`customer_state` `c` LEFT JOIN `bank`.`spouse` `s` ON ((`s`.`spouse_id` = `c`.`spouse_id`)))
   WHERE (`p`.`nic` = `c`.`nic`));
